import os
import numpy as np
import matplotlib.pyplot as plt
from d3qn import Agent
from env_SC import SCenvironment
import random
#plot learning
# env = gym.make('LunarLander-v2')
# n_actions = env.action_space.n
from math import log2
from pandas import DataFrame
n_actions=20
# obs_shape = list(env.observation_space.shape)
obs_shape=6
n_games = 5000
rewards = []
eps_history = []
done = False
score = 0
state = np.zeros(obs_shape)
avgrewards=[]
latencys=[]
if __name__ == '__main__':

    agent = Agent(gamma = 0.99, n_actions = n_actions, epsilon = 1.0, batch_size = 64, input_dims = 6)
    snr_dbs=[]
    for i in range(n_games):

        '''state generate'''
        # Trans_resource=1095*6912*(np.sin(i/100)*0.4+0.6)
                # rand_num=random.uniform(0.5, 1)
        # Rece_resource=1607*2560*(np.sin(-i/100)*0.2+0.8)
        # Trans_resource=1095*6912*random.uniform(0.4, 1)
        # Rece_resource=1607*2560*random.uniform(0.6, 1)

        Trans_resource=1095*6912*1
        Rece_resource=1607*2560*random.uniform(0.6, 1)

        Bandwidth=20+random.randint(-15,0)
        # snr_db=int(2*log2(1+i)+np.sin(i/100)**2)
        snr_db=random.randint(-6,15)
        snr_dbs.append(snr_db)
        # latency_high=10+random.uniform(-6,10)+0.5*(snr_db)
        latency_high=15+random.uniform(-10,10)
        # latency_high=3+0.5*snr_db

        # env.render()
        # while not done:
            # env.render()
        action = agent.choose_action(state)
        rece_diff=int((latency_high-action*0.1)/0.3-snr_db/10+2)  
 
        # obs_, reward, done, info = env.step(action)
        env=SCenvironment(action,state,Trans_resource, Rece_resource,Bandwidth,snr_db,latency_high,rece_diff)
        state_=env.State()
        reward=env.Reward()
        rewards.append(reward)
        avg_reward = np.mean(rewards[-10:])

        agent.store_transition(state, action, avg_reward, state_, int(done))
        # score += reward
        state = state_
        agent.learn()
        eps_history.append(agent.epsilon)
        com_l=env.computLatencyCal()
        tran_l=env.transLatencyCal()
        latency=env.latencyCal()

        latencys.append(latency)
        
        avgrewards.append(avg_reward)
        if i % 5 == 0:
            print('episode: {}\t curr_score: {}\t avg score: {}'.format(i, reward,avg_reward))

    linspace = np.linspace(0, 1, len(rewards))
    # plt.plot(linspace, rewards)
    plt.ylabel('Rewards')
    plt.xlabel('Games')
    plt.savefig('scores_base.png')
    plt.plot(linspace,avgrewards)
    plt.show()
    plt.figure()

    plt.plot(linspace,latencys)
    plt.show()

# def receDiffStep(diff_latents,target_latents):
#     loss = nn.MSELoss()
#     loss_diff=loss(diff_latents,target_latents)
#     if loss_diff<=val_loss:
#         return 
df=DataFrame({'episode':range(0,n_games),'reward':rewards,'reward_total':avgrewards,'Latency':latencys,'SNR':snr_dbs})
os.makedirs('dataset', exist_ok=True)  
csvname='dataset/SCAIGC_0923_C1.csv'
# csvname='dataset/NoSCout_0727_ue200.csv'
df.to_csv(csvname,index=None) 