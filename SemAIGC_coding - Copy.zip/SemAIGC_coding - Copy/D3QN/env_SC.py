import numpy as np
import torch
from math import log2
import matplotlib.pyplot as plt
#Computional resource setting Trans GPU GTX A6000, Rece GPU GTX 1080 
# Cspeed_T = 1455 #MHz= 10951000000 cycles/s 
# corenumber_T=10752
# Cspeed_R = 1320
# corenumber_R=3584
# #Communication resource setting 
# Bandwidth=20 #Mb
# Channel_condition = 0 #dB
# k_bs = 10**(-2)#path loss constant
# e_bs = 4#path loss exponent
# p_bs = 40000 #40W=40000mW#transmission power
# d_bs2r = 50 #m distance
# sigma_n = -174 #dBm Signal dBm- Noise dBm=SINR dB
# snr=10 #dB


# file_size = 512*512*3#bit
# File_size_s=64*64*4


class SCenvironment():
    def __init__(self,action,state,Trans_resource, Rece_resource,Bandwidth,snr_db,latency_high,rece_diff):
        self.Trans_resource=Trans_resource
        self.Rece_resource=Rece_resource
        # self.Channel_condition=Channel_condition
        self.Bandwidth=Bandwidth
        self.action=action
        self.latency_high=latency_high
        self.snr_db=snr_db
        self.rece_diff=rece_diff
        # self.episode=episode
        self.state=state
        self.latency=[]
        

    def wgn(self,latents,snr):
        h_latents=latents.shape[2]
        w_latents=latents.shape[3]
        Ps=torch.sum(torch.pow(latents,2))/h_latents/w_latents
        Pn=Ps/(np.power(10,snr/10))
        noise=torch.randn(latents.shape).uniform_(0,1)*torch.sqrt(Pn)
        return noise

    def bit_error_rate(self,snr_db):
        snr = 10 ** (snr_db / 10.0)  # Convert SNR from dB to linear scale
        ber = 0.5 * np.exp(-snr)  # Simplified formula for BPSK modulation
        return ber

    def transLatencyCal(self,semantic_size=64*64*4):
        #SINR Calculate 
        # snr = 10 * np.log10(p_bs) * k_bs * (d_bs2r ** (-e_bs)) - sigma_n 
        snr = 10 ** (self.snr_db / 10.0) 
        t_rate = self.Bandwidth * log2(1 + snr)
        latency_tran=semantic_size*8/t_rate/1000000
        return t_rate, latency_tran
    
    def CPL(self,density_process,file_size,para_rate,corenumber,Cspeed):
        latency_com=(1-para_rate+(para_rate/corenumber))*density_process*file_size/Cspeed
        return latency_com
    
    def computLatencyCal(self,semantic_size=64*64*4,file_size=512*512*3,para_rate=1,corenumber=1):
        density_process_e=1095*6912*1.5*0.5*0.5/file_size #cycles
        density_process_u=1095*6912*0.4*0.5*0.5/semantic_size #cycles
        density_process_r=1095*6912*1.3*0.5*0.5/semantic_size#cycles
        L_ext=self.CPL(density_process_e,file_size,corenumber,para_rate,self.Trans_resource)
        L_Unet_t=self.CPL(density_process_u,semantic_size,corenumber,para_rate,self.Trans_resource)*self.action
        L_Unet_r=self.CPL(density_process_u,semantic_size,corenumber,para_rate,self.Rece_resource)*(self.rece_diff)
        L_rec=self.CPL(density_process_r,semantic_size,corenumber,para_rate,self.Rece_resource)
        # latency_com=(1-para_rate+(para_rate/corenumber))*density_process*file_size/Cspeed
        return L_ext,L_Unet_t,L_Unet_r,L_rec
        
    def latencyCal(self):
        
        self.latency=np.sum(self.computLatencyCal())+self.transLatencyCal()[1]
    # Generate a range of SNR values in dB
        return self.latency

    def Reward(self):
        self.latencyCal()
        if self.latency < self.latency_high:
            reward=1
        elif self.latency >self.latency_high*2:
            reward=0
        else:
            reward=(self.latency-self.latency_high)/(self.latency_high)
        return reward
    
        # if self.latency < self.latency_high:
        #     reward=(self.latency-self.latency_high)/(self.latency_high)
        # elif self.latency >self.latency_high*2:
        #     reward=0
        # else:
        #     reward=(self.latency-self.latency_high)/(self.latency_high)
        # return reward

    def State(self):#SNR
        state_=np.zeros(6)
        dis_rate=0.6
        state_[0]=self.Trans_resource*dis_rate+self.state[0]*(1-dis_rate)
        state_[1]=self.Rece_resource*dis_rate+self.state[1]*(1-dis_rate)
        state_[2]=self.Bandwidth*dis_rate+self.state[2]*(1-dis_rate)
        state_[3]=self.snr_db*dis_rate+self.state[3]*(1-dis_rate)
        state_[4]=self.latency_high*dis_rate+self.state[4]*(1-dis_rate)
        state_[5]=self.rece_diff*dis_rate+self.state[5]*(1-dis_rate)
        return state_


# def histBand(current_SNR,hist_SNR,dis_rate):#Bandwidth
#     ave_SNR=current_SNR*dis_rate+hist_SNR*(1-dis_rate)
#     return ave_SNR
# def histCP():#computing power

# def histLR():#latency requirement
